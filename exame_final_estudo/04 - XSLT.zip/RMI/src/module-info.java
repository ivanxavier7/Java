/**
 * 
 */
/**
 * @author ivanx
 *
 */
module RMI {
	requires java.rmi;
}