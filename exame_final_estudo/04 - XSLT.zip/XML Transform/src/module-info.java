/**
 * 
 */
/**
 * @author ivanx
 *
 */
module XML_Schema {
}