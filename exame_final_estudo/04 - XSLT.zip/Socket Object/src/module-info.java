/**
 * 
 */
/**
 * @author ivanx
 *
 */
module DatagramSocket {
}