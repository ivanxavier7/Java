package com.example.spring_jaxb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringJaxbApplicationTests {

	@Test
	void contextLoads() {
	}

}
