package com.example.rest_h2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestH2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
